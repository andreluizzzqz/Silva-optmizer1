# Otimizador Pro (Android, sem root)

App em Kotlin + Jetpack Compose + Material 3 (minSdk 29). Tudo que está na tela executa um comando real; nada é simulado.

## Como rodar
1. Abra a pasta no Android Studio (Ladybug ou mais novo) e deixe o Gradle sincronizar.
2. Rode no celular (Android 10+).
3. Instale o app **Shizuku** (Play Store/GitHub), inicie-o por Depuração sem fio (Android 11+) ou ADB, e autorize o Otimizador Pro.

## O que faz
| Função | Como | Precisa de |
|---|---|---|
| Reduzir/desligar animações | `Settings.Global` (window/transition/animator scale) | Shizuku **ou** `adb shell pm grant com.otimizador.app android.permission.WRITE_SECURE_SETTINGS` |
| Tirar delay de toque longo | `Settings.Secure long_press_timeout` | idem |
| Desativar app do sistema | `pm disable-user --user 0` | Shizuku |
| Desinstalar app do sistema (p/ usuário 0) | `pm uninstall -k --user 0` | Shizuku |
| Restaurar app removido | `pm enable` / `cmd package install-existing` | Shizuku |
| Limpar cache de todos os apps | `pm trim-caches` | Shizuku |
| Encerrar apps em segundo plano | `am kill-all` | Shizuku |
| Otimizar apps (AOT) | `cmd package compile -m speed-profile -a` | Shizuku |

## Segurança
- Lista de pacotes protegidos (SystemUI, telefone, configurações, Play Services, teclado, instalador etc.) não pode ser selecionada.
- Tudo que é removido fica registrado para "Restaurar".
- Mesmo assim, desativar apps de fabricante pode causar bugs. Teste com poucos apps por vez.

## Limites do Android sem root
Não existe app que, sem root/ADB, apague apps do sistema ou limpe cache de terceiros: o Android bloqueia. Apps "otimizadores" que prometem isso sem permissão especial só mostram anúncios.
