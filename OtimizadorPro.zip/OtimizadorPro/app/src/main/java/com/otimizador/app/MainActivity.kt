package com.otimizador.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ShellClient.init(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF4F8CFF),
                    secondary = Color(0xFF8B5CF6),
                    background = Color(0xFF0D0F1A),
                    surface = Color(0xFF161A2B),
                )
            ) { Root() }
        }
    }

    override fun onResume() {
        super.onResume()
        ShellClient.refresh()
    }
}

@Composable
fun Root() {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Início", "Animações", "Apps", "Limpeza")
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column(Modifier.statusBarsPadding()) {
                TabRow(selectedTabIndex = tab) {
                    tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontSize = 13.sp) }) }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeTab()
                1 -> AnimTab()
                2 -> AppsTab()
                else -> CleanTab()
            }
        }
    }
}

@Composable
fun LogBox() {
    val log by Tweaks.log.collectAsState()
    if (log.isNotBlank()) {
        Card(Modifier.fillMaxWidth().padding(top = 12.dp)) {
            Text(log, Modifier.padding(12.dp), fontSize = 11.sp)
        }
    }
}

@Composable
fun HomeTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val status by ShellClient.status.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Otimizador Pro", fontSize = 24.sp, color = MaterialTheme.colorScheme.primary)
        Text(
            when (status) {
                ShellStatus.NOT_RUNNING -> "Shizuku: não está rodando"
                ShellStatus.NO_PERMISSION -> "Shizuku: rodando, falta autorizar este app"
                ShellStatus.CONNECTING -> "Shizuku: conectando…"
                ShellStatus.READY -> "Shizuku: conectado ✓ (todas as funções liberadas)"
            }
        )
        Text(
            "Sem root, o Android bloqueia desinstalar apps do sistema e limpar cache de outros apps. " +
                "O Shizuku dá ao app permissão de ADB (shell) sem root. Sem ele, só funcionam as animações " +
                "(via comando ADB único abaixo) e a limpeza do próprio app.",
            fontSize = 13.sp
        )
        when (status) {
            ShellStatus.NOT_RUNNING -> OutlinedButton(onClick = {
                ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { ctx.startActivity(it) }
            }) { Text("Abrir app Shizuku") }
            ShellStatus.NO_PERMISSION -> Button(onClick = { ShellClient.requestPermission() }) { Text("Autorizar este app no Shizuku") }
            ShellStatus.READY -> {
                Button(onClick = { scope.launch { Tweaks.optimizeAll(ctx) } }, Modifier.fillMaxWidth()) { Text("OTIMIZAR TUDO") }
                OutlinedButton(onClick = { scope.launch { Tweaks.grantSecureSettings(ctx) } }) { Text("Conceder WRITE_SECURE_SETTINGS (animações sem Shizuku)") }
            }
            else -> {}
        }
        Text("Alternativa sem Shizuku (1x pelo PC, USB/Wi-Fi debug):", fontSize = 12.sp)
        Text("adb shell pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
        LogBox()
    }
}

@Composable
fun AnimTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Animações do sistema", fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { scope.launch { Tweaks.setAnimations(ctx, "0") } }) { Text("Desligar") }
            Button(onClick = { scope.launch { Tweaks.setAnimations(ctx, "0.5") } }) { Text("0.5x") }
            OutlinedButton(onClick = { scope.launch { Tweaks.setAnimations(ctx, "1") } }) { Text("Padrão") }
        }
        Text("Delay de toque longo", fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { scope.launch { Tweaks.setLongPress(ctx, 250) } }) { Text("Rápido (250 ms)") }
            OutlinedButton(onClick = { scope.launch { Tweaks.setLongPress(ctx, 400) } }) { Text("Padrão (400 ms)") }
        }
        Text(
            "Requer Shizuku ou a permissão WRITE_SECURE_SETTINGS concedida (aba Início). " +
                "O resultado real aparece no log abaixo.",
            fontSize = 12.sp
        )
        LogBox()
    }
}

@Composable
fun AppsTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var confirm by remember { mutableStateOf<String?>(null) }
    var removed by remember { mutableStateOf(SystemApps.removed(ctx)) }
    var showRemoved by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { SystemApps.list(ctx) } }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ver removidos (${removed.size})", Modifier.weight(1f))
            Switch(checked = showRemoved, onCheckedChange = { showRemoved = it })
        }
        if (showRemoved) {
            LazyColumn(Modifier.weight(1f)) {
                items(removed.toList()) { entry ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(entry.replace("|", "  •  "), Modifier.weight(1f), fontSize = 12.sp)
                        TextButton(onClick = {
                            scope.launch { SystemApps.restore(ctx, entry); removed = SystemApps.removed(ctx) }
                        }) { Text("Restaurar") }
                    }
                }
            }
        } else {
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("Buscar app do sistema") }, singleLine = true)
            val shown = apps.filter { query.isBlank() || it.label.contains(query, true) || it.pkg.contains(query, true) }
            LazyColumn(Modifier.weight(1f)) {
                items(shown, key = { it.pkg }) { a ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = a.pkg in selected,
                            enabled = !a.critical,
                            onCheckedChange = { selected = if (it) selected + a.pkg else selected - a.pkg }
                        )
                        Column(Modifier.weight(1f)) {
                            Text(a.label, fontSize = 14.sp)
                            Text(
                                a.pkg + when {
                                    a.critical -> "  • protegido"
                                    a.suggested -> "  • sugerido"
                                    else -> ""
                                },
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                Button(enabled = selected.isNotEmpty(), onClick = { confirm = "disable" }) { Text("Desativar") }
                Button(enabled = selected.isNotEmpty(), onClick = { confirm = "uninstall" }) { Text("Desinstalar") }
            }
        }
        LogBox()
    }

    confirm?.let { action ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (action == "disable") "Desativar ${selected.size} app(s)?" else "Desinstalar ${selected.size} app(s) do sistema?") },
            text = {
                Text(
                    "É reversível pela opção 'Ver removidos' (ou factory reset). Remover o app errado " +
                        "pode causar bugs. Apps protegidos não podem ser selecionados."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val list = selected.toList()
                    confirm = null
                    selected = emptySet()
                    scope.launch {
                        list.forEach { if (action == "disable") SystemApps.disable(ctx, it) else SystemApps.uninstallForUser(ctx, it) }
                        removed = SystemApps.removed(ctx)
                        apps = withContext(Dispatchers.IO) { SystemApps.list(ctx) }
                    }
                }) { Text("Confirmar") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun CleanTab() {
    val ctx: Context = LocalContext.current
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Limpeza e desempenho (Shizuku)", fontSize = 18.sp)
        Button(onClick = { scope.launch { Tweaks.trimAllCaches() } }, Modifier.fillMaxWidth()) { Text("Limpar cache de TODOS os apps") }
        Button(onClick = { scope.launch { Tweaks.killBackground() } }, Modifier.fillMaxWidth()) { Text("Encerrar apps em segundo plano") }
        Button(onClick = { scope.launch { Tweaks.optimizeDex() } }, Modifier.fillMaxWidth()) { Text("Otimizar apps (compilação AOT)") }
        Text("Sem Shizuku", fontSize = 18.sp)
        OutlinedButton(onClick = { Tweaks.clearOwnCache(ctx) }, Modifier.fillMaxWidth()) { Text("Limpar cache deste app") }
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }, Modifier.fillMaxWidth()) { Text("Abrir Armazenamento do Android") }
        LogBox()
    }
}
