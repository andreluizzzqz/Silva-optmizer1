package com.otimizador.app

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShellStatus { NOT_RUNNING, NO_PERMISSION, CONNECTING, READY }

object ShellClient {
    private var service: IShellService? = null
    private val _status = MutableStateFlow(ShellStatus.NOT_RUNNING)
    val status: StateFlow<ShellStatus> = _status

    private lateinit var appCtx: Context

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = IShellService.Stub.asInterface(binder)
            _status.value = ShellStatus.READY
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            refresh()
        }
    }

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        Shizuku.addBinderReceivedListenerSticky { refresh() }
        Shizuku.addBinderDeadListener { service = null; _status.value = ShellStatus.NOT_RUNNING }
        Shizuku.addRequestPermissionResultListener { _, _ -> refresh() }
    }

    fun refresh() {
        val running = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        if (!running) { _status.value = ShellStatus.NOT_RUNNING; return }
        val granted = try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) { false }
        if (!granted) { _status.value = ShellStatus.NO_PERMISSION; return }
        if (service == null) {
            _status.value = ShellStatus.CONNECTING
            val args = Shizuku.UserServiceArgs(ComponentName(appCtx.packageName, ShellService::class.java.name))
                .daemon(false)
                .processNameSuffix("shell")
                .version(1)
            try { Shizuku.bindUserService(args, conn) } catch (_: Throwable) { _status.value = ShellStatus.NOT_RUNNING }
        } else {
            _status.value = ShellStatus.READY
        }
    }

    fun requestPermission() {
        try { Shizuku.requestPermission(1001) } catch (_: Throwable) { }
    }

    suspend fun exec(cmd: String): String = withContext(Dispatchers.IO) {
        val s = service ?: return@withContext "Shizuku não conectado (veja a aba Início)."
        try { s.exec(cmd) } catch (e: Exception) { "Erro: ${e.message}" }
    }
}
