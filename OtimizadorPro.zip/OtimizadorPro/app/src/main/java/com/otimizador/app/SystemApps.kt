package com.otimizador.app

import android.content.Context
import android.content.pm.ApplicationInfo

data class AppItem(
    val pkg: String,
    val label: String,
    val critical: Boolean,
    val suggested: Boolean,
)

object SystemApps {
    private val validPkg = Regex("^[A-Za-z0-9._]+$")

    /** Nunca permitir mexer: quebram boot, ligações, rede, teclado, loja, instalador, etc. */
    private val criticalPrefixes = listOf(
        "com.android.systemui", "com.android.phone", "com.android.settings", "com.android.providers",
        "com.android.launcher", "com.android.server", "com.android.shell", "com.android.bluetooth",
        "com.android.nfc", "com.android.inputmethod", "com.android.packageinstaller",
        "com.android.permissioncontroller", "com.android.keychain", "com.android.certinstaller",
        "com.android.networkstack", "com.android.wifi", "com.android.cellbroadcast", "com.android.location",
        "com.android.webview", "com.android.vending", "com.android.mms", "com.android.dialer",
        "com.android.contacts", "com.android.emergency", "com.android.storagemanager",
        "com.android.cts", "com.android.carrier", "com.android.se", "com.android.stk",
        "com.google.android.gms", "com.google.android.gsf", "com.google.android.webview",
        "com.google.android.inputmethod", "com.google.android.packageinstaller",
        "com.google.android.permissioncontroller", "com.google.android.dialer",
        "com.google.android.apps.messaging", "com.google.android.ext", "com.google.android.networkstack",
        "com.google.android.documentsui", "com.google.android.setupwizard", "com.google.android.apps.nexuslauncher",
        "com.sec.android.app.launcher", "com.samsung.android.dialer", "com.samsung.android.messaging",
        "com.samsung.android.incallui", "com.samsung.android.app.settings", "com.miui.home",
        "com.miui.securitycenter", "com.xiaomi.finddevice", "com.miui.system", "com.motorola.launcher",
        "com.otimizador.app",
    )

    /** Heurística de "bloatware" comum. É sugestão, não garantia: confira antes. */
    private val suggestedPrefixes = listOf(
        "com.facebook.", "com.netflix.", "com.amazon.", "com.linkedin.", "com.microsoft.skydrive",
        "com.microsoft.office.", "com.google.android.videos", "com.google.android.music",
        "com.google.android.apps.magazines", "com.google.android.apps.podcasts",
        "com.miui.analytics", "com.miui.msa.global", "com.miui.bugreport", "com.miui.hybrid",
        "com.samsung.android.bixby.agent", "com.samsung.android.bixby.wakeup",
        "com.samsung.android.app.tips", "com.samsung.android.visionintelligence",
        "com.samsung.android.stickercenter", "com.samsung.android.ardrawing",
    )

    fun isValid(pkg: String) = validPkg.matches(pkg)

    fun list(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM != 0 }
            .map { ai ->
                val p = ai.packageName
                AppItem(
                    pkg = p,
                    label = pm.getApplicationLabel(ai).toString(),
                    critical = p == "android" || criticalPrefixes.any { p.startsWith(it) },
                    suggested = suggestedPrefixes.any { p.startsWith(it) },
                )
            }
            .sortedWith(compareByDescending<AppItem> { it.suggested }.thenBy { it.label.lowercase() })
    }

    // Registro local do que foi removido/desativado, para permitir restaurar
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("removed", Context.MODE_PRIVATE)

    /** Entradas no formato "pacote|acao" (acao = disable | uninstall). */
    fun removed(ctx: Context): Set<String> = prefs(ctx).getStringSet("items", emptySet()) ?: emptySet()

    fun mark(ctx: Context, pkg: String, action: String) {
        prefs(ctx).edit().putStringSet("items", removed(ctx) + "$pkg|$action").apply()
    }

    fun unmark(ctx: Context, entry: String) {
        prefs(ctx).edit().putStringSet("items", removed(ctx) - entry).apply()
    }

    suspend fun disable(ctx: Context, pkg: String) {
        if (!isValid(pkg)) return
        Tweaks.sh("pm disable-user --user 0 $pkg")
        mark(ctx, pkg, "disable")
    }

    suspend fun uninstallForUser(ctx: Context, pkg: String) {
        if (!isValid(pkg)) return
        Tweaks.sh("pm uninstall -k --user 0 $pkg")
        mark(ctx, pkg, "uninstall")
    }

    suspend fun restore(ctx: Context, entry: String) {
        val (pkg, action) = entry.split("|").let { it[0] to it.getOrElse(1) { "" } }
        if (!isValid(pkg)) return
        if (action == "disable") Tweaks.sh("pm enable $pkg") else Tweaks.sh("cmd package install-existing $pkg")
        unmark(ctx, entry)
    }
}
