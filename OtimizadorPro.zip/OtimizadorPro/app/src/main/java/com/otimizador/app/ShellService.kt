package com.otimizador.app

import kotlin.system.exitProcess

/** Roda dentro do processo "shell" (UID 2000) iniciado pelo Shizuku. */
class ShellService : IShellService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String): String = try {
        val p = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.ifBlank { "(ok)" }
    } catch (e: Exception) {
        "Erro: ${e.message}"
    }
}
