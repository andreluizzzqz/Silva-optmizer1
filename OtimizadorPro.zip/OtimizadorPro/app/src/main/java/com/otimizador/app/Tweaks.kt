package com.otimizador.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import kotlinx.coroutines.flow.MutableStateFlow

/** Todas as ações reais. Cada uma loga o resultado verdadeiro do sistema. */
object Tweaks {
    val log = MutableStateFlow("")

    private fun append(s: String) {
        log.value = (log.value + s + "\n").takeLast(6000)
    }

    fun ready() = ShellClient.status.value == ShellStatus.READY

    suspend fun sh(cmd: String): String {
        if (!ready()) {
            append("✗ Precisa do Shizuku ativo: $cmd")
            return ""
        }
        val out = ShellClient.exec(cmd)
        append("$ $cmd\n${out.trim()}")
        return out
    }

    /** Escreve em Settings.Global/Secure: direto se tiver WRITE_SECURE_SETTINGS, senão via Shizuku. */
    suspend fun putSetting(ctx: Context, ns: String, key: String, value: String) {
        val hasSecure = ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED
        if (hasSecure) {
            val ok = try {
                when (ns) {
                    "global" -> Settings.Global.putString(ctx.contentResolver, key, value)
                    "secure" -> Settings.Secure.putString(ctx.contentResolver, key, value)
                    else -> false
                }
            } catch (e: SecurityException) { false }
            append(if (ok) "✓ $ns $key = $value" else "✗ Falhou ao gravar $ns $key")
        } else if (ready()) {
            sh("settings put $ns $key $value")
        } else {
            append("✗ Sem permissão para $key. Use Shizuku ou o comando ADB da aba Início.")
        }
    }

    suspend fun setAnimations(ctx: Context, scale: String) {
        for (k in listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")) {
            putSetting(ctx, "global", k, scale)
        }
    }

    /** Tempo de long-press (padrão do Android: 400 ms). Menor = toque longo responde mais rápido. */
    suspend fun setLongPress(ctx: Context, ms: Int) = putSetting(ctx, "secure", "long_press_timeout", ms.toString())

    suspend fun grantSecureSettings(ctx: Context) {
        sh("pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS")
    }

    suspend fun trimAllCaches() = sh("pm trim-caches 999G")

    suspend fun killBackground() = sh("am kill-all")

    /** Compila apps em segundo plano (pode demorar vários minutos; roda desacoplado). */
    suspend fun optimizeDex() = sh("(cmd package compile -m speed-profile -a >/dev/null 2>&1 &) ; echo iniciado em segundo plano")

    fun clearOwnCache(ctx: Context) {
        val ok = ctx.cacheDir.deleteRecursively()
        append(if (ok) "✓ Cache do próprio app limpo" else "✗ Não foi possível limpar o cache do app")
    }

    suspend fun optimizeAll(ctx: Context) {
        setAnimations(ctx, "0.5")
        trimAllCaches()
        killBackground()
        optimizeDex()
    }
}
