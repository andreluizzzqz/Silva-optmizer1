package com.otimizador.app;

interface IShellService {
    // Código de transação reservado pelo Shizuku
    void destroy() = 16777114;

    String exec(String command) = 1;
}
